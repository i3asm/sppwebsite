<?php $__env->startSection('title'); ?>
	<title>Hi</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <h1>today's news</h1>
        <p><?php echo e($person->position); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mainStyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/i3asm/sites/sppwebsite/resources/views/news.blade.php ENDPATH**/ ?>