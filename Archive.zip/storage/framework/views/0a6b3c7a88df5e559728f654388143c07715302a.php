<?php $__env->startSection('head'); ?>
	<style>
		.year {

		}

		.person {

		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

	<?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<h3 class="year"><?php echo e($year); ?>:</h3>
		<?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($year == $person->year): ?>
				<p class="person name">الاسم: <?php echo e($person->name); ?></p>
				<p class="person position">المنصب: <?php echo e($person->position); ?></p>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('mainStyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/i3asm/sites/sppwebsite/resources/views/archive.blade.php ENDPATH**/ ?>