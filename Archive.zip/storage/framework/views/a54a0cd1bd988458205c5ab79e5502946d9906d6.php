<?php $__env->startSection('content'); ?>
    <div class="flex-center position-ref full-height">

        <div class="content">
            <div class="title m-b-md">
                <?php echo e($name ?? 'Laravel'); ?>

            </div>

            <div class="links">
                <a href="https://laravel.com/docs"><?php echo e($ID ?? 'Docs'); ?></a>
                <a href="https://laracasts.com"><?php echo e($age ?? 'Laracasts'); ?></a>
                
                
                
                
                
                
            </div>
        </div>















    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mainStyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/i3asm/dev/sppwebsite/resources/views/welcome.blade.php ENDPATH**/ ?>