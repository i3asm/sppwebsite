<?php $__env->startSection('head'); ?>
	<style>
		body{
			margin: 50px;
		}
	</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
	
	

	<?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<h3 class="year"><?php echo e($year); ?>:</h3>
		<?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($year == $person->year): ?>

				<form method="POST" action="/dashboard">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PUT'); ?>
					<input type="hidden" name="id" value="<?php echo e($person->id); ?>">
					<input type="number" name="year" min="2008" max="2030" step="1" value="<?php echo e($person->year); ?>">
					<input type="text" name="name" value="<?php echo e($person->name); ?>">
					<input type="text" name="position" value="<?php echo e($person->position); ?>">
					<button type="submit">تحديث البيانات</button>
				</form>
				<form method="post" action="dashboard">
					<?php echo csrf_field(); ?>
					<?php echo method_field('DELETE'); ?>
					<input type="hidden" name="id" value="<?php echo e($person->id); ?>">
					<button type="submit">حذف البيانات</button>
				</form>

				<br>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<?php $__env->startComponent('dashboard.addArchive'); ?> <?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('mainStyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/i3asm/sites/sppwebsite/resources/views/DashBoard.blade.php ENDPATH**/ ?>