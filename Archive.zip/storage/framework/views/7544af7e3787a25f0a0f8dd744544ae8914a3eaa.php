


	<style>
		body{
		}
	</style>
	<h2>إضافة أشخاص:</h2>
	<form method="POST" action="/dashboard">
		<?php echo csrf_field(); ?>
		<p class="year"> السنة : </p>
		<input type="number" name="year" min="1350" max="2050" step="1" required>


		<p class="name"> الاسم : </p>
		<input type="text" name="name" required>


		<p class="name"> المنصب : </p>
		<input type="text" name="position" placeholder="ننصح باستخدم اسم موحد لكل منصب" required>

		<button type="submit">إرسال</button>
	</form>
<?php /**PATH /Users/i3asm/sites/sppwebsite/resources/views/dashboard/addArchive.blade.php ENDPATH**/ ?>