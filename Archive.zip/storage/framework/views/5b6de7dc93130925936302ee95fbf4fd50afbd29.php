<?php $__env->startSection('body'); ?>
	<form method="POST" action="/archive">
		<?php echo csrf_field(); ?>
		<p class="year"> السنة : </p>
		<input type="number" name="year" min="2008" max="2030" step="1">
		<br>

		<p class="name"> الاسم : </p>
		<input type="text" name="name">
		<br>

		<p class="name"> المنصب : </p>
		<input type="text" name="position" placeholder="ننصح باستخدم اسم موحد لكل منصب">

		<br>
		<button type="submit">إرسال</button>
	</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mainStyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/i3asm/sites/sppwebsite/resources/views/forms/editArchives.blade.php ENDPATH**/ ?>