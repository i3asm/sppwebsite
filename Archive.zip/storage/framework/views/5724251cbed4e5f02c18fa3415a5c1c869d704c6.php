<!DOCTYPE html>



<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<?php echo $__env->yieldContent('title'); ?>

	<!-- Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Tajawal&display=swap" rel="stylesheet">

	<!-- Styles -->
	<style>
		html, body {
			background-color: #fff;
			font-family: 'Tajawal', sans-serif;
			margin: 0;
			/*direction: rtl;*/
		}
	</style>

	<?php echo $__env->yieldContent('head'); ?>
</head>

<body>




<?php echo $__env->yieldContent('body'); ?>




</body>
</html>
<?php /**PATH /Users/i3asm/sites/sppwebsite/resources/views/mainStyle.blade.php ENDPATH**/ ?>